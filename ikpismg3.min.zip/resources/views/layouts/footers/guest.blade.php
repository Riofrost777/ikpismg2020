<footer class="footer">
    <div class="container">
        <nav class="float-left">
            <ul>
                <li>
                    <a href="https://web.facebook.com/ikpismg-101242741344533/" target="_blank" data-original-title="" title="facebook" style="color: #3B5998">
                        <i class="fa fa-facebook-square"></i>
                        <div class="ripple-container"></div>
                        {{ __('Contact us') }}
                    </a>
                </li>
                <li>
                    <a href="https://www.instagram.com/ikpismg" target="_blank" data-original-title="" title="instagram" style="color:  #E1306C">
                        <i class="fa fa-instagram"></i>
                        <div class="ripple-container"></div>
                        {{ __('Follow us') }}
                    </a>
                </li>
            </ul>
        </nav>
        <div class="copyright float-right">
        &copy;
        <script>
            document.write(new Date().getFullYear())
        </script>, made by
        <a href="https://www.instagram.com/abrahamriorizky/" target="_blank">Rio</a> for a better web.
        </div>
    </div>
</footer>