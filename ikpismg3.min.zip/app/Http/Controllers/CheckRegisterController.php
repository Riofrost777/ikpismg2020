<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CheckRegisterController extends Controller
{
    public function checkIfRegistered(Request $request)
    {
    	use checkRegisterNumber;

    	$data
    	if ($check->registerFlag == 0) {
   			// user can register
   			
		}
    }
}
