<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PPLController extends Controller
{
    //
}
